import Link from 'next/link'
import { Breadcrumbs } from '@/components/breadcrumbs'
import { ActionButton } from '@/components/tool-kit/controls'
import { Compass, Home, Search } from 'lucide-react'

export function NotFoundPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 sm:py-24 text-center">
      <Breadcrumbs
        items={[
          { label: 'Home', href: '/' },
          { label: 'Page Not Found', href: '#' },
        ]}
      />

      <div className="mt-10 flex flex-col items-center">
        <div className="size-20 rounded-2xl bg-muted/60 flex items-center justify-center text-primary mb-6">
          <Compass className="size-10" />
        </div>
        <span className="font-mono text-sm uppercase tracking-wider text-muted-foreground">404 Error</span>
        <h1 className="mt-2 text-3xl font-bold tracking-tight sm:text-5xl">Page not found</h1>
        <p className="mt-4 max-w-md text-muted-foreground text-sm sm:text-base leading-relaxed">
          The page or tool you are looking for might have been moved or does not exist.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link href="/">
            <ActionButton variant="primary">
              <Home aria-hidden="true" />
              Back to Home
            </ActionButton>
          </Link>
          <Link href="/tools">
            <ActionButton>
              <Search aria-hidden="true" />
              Explore All Tools
            </ActionButton>
          </Link>
        </div>
      </div>
    </div>
  )
}
