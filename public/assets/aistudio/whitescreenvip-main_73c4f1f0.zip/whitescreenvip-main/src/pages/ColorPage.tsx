import { Hero } from '@/components/home/hero'
import { Section } from '@/components/section'
import { ColorScreenLinks } from '@/components/color-screen-links'
import { JsonLd } from '@/components/json-ld'
import { getColorBySlug, type ScreenColor } from '@/lib/screen-colors'
import { colorPages } from '@/lib/color-pages'
import { absoluteUrl } from '@/lib/site'

export function ColorPage({ color }: { color: ScreenColor }) {
  const content = colorPages[color.id] || {
    intro: `A solid fullscreen ${color.name.toLowerCase()} screen.`,
    uses: [
      { title: 'Screen testing', description: `Check pixel subpixels and backlight uniformity with pure ${color.name.toLowerCase()}.` },
      { title: 'Photography & video', description: `Use as a pure ${color.name.toLowerCase()} ambient backdrop.` },
      { title: 'Focus & lighting', description: `Clean colored light source for mood or workspace ambient illumination.` },
    ],
    description: `A fullscreen ${color.name.toLowerCase()} screen.`,
  }

  const schema = {
    '@context': 'https://schema.org',
    '@type': 'WebApplication',
    name: `${color.name} Screen`,
    url: absoluteUrl(color.path),
    description: content.description,
    applicationCategory: 'UtilitiesApplication',
    operatingSystem: 'Any',
    browserRequirements: 'Requires a modern web browser',
    offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
  }

  return (
    <>
      <JsonLd data={schema} />
      <Hero colorId={color.id} title={`${color.name} Screen`} intro={content.intro} />
      <Section
        id="use-cases"
        eyebrow="Use cases"
        title={`What you can use a ${color.name.toLowerCase()} screen for`}
        className="border-y bg-muted/40"
      >
        <ul className="grid gap-px overflow-hidden rounded-xl border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {content.uses.map((use) => (
            <li key={use.title} className="bg-card p-6">
              <h3 className="font-medium">{use.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                {use.description}
              </p>
            </li>
          ))}
        </ul>
      </Section>
      <ColorScreenLinks currentId={color.id} />
    </>
  )
}
