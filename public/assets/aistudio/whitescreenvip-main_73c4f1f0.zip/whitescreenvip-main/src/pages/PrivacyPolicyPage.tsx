import { ContentPage } from '@/components/content-page'
import { siteConfig } from '@/lib/site'

const description =
  'Read how WhiteScreen.vip handles your data. The screen tool runs locally in your browser and does not collect personal information.'

export function PrivacyPolicyPage() {
  return (
    <ContentPage title="Privacy Policy" description={description} updated="October 21, 2026">
      <h2>Information we collect</h2>
      <p>
        The white screen tool and all utility suites run entirely in your browser. Your color choices,
        settings, timers, and camera feeds (for video props) are processed strictly client-side on your
        own hardware and are never transmitted to our servers.
      </p>
      <h2>Camera & microphone permissions</h2>
      <p>
        Certain optional simulation tools (such as Fake Video Call) offer the ability to preview your local
        webcam. Any video stream is rendered strictly within your browser DOM and is never recorded, saved,
        streamed, or uploaded anywhere.
      </p>
      <h2>Analytics</h2>
      <p>
        We use privacy-friendly, aggregated analytics to understand overall traffic, such as page views and
        approximate country. This data does not identify you personally and does not use advertising cookies.
      </p>
      <h2>Cookies & local storage</h2>
      <p>We do not use tracking or advertising cookies. Any preference saving is kept strictly on your device.</p>
      <h2>Third parties</h2>
      <p>
        Our site is hosted on cloud infrastructure that may process standard network request headers, such as IP
        address and user-agent string, to serve assets securely.
      </p>
      <h2>Contact</h2>
      <p>
        Questions about privacy? Email{' '}
        <a href={`mailto:${siteConfig.contactEmail}`}>{siteConfig.contactEmail}</a>.
      </p>
    </ContentPage>
  )
}
