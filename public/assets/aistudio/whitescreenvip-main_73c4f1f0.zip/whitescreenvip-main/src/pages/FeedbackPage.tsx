import { useState } from 'react'
import { ContentPage } from '@/components/content-page'
import { ActionButton } from '@/components/tool-kit/controls'
import { Star, CheckCircle, Send } from 'lucide-react'
import { cn } from '@/lib/utils'

export function FeedbackPage() {
  const [rating, setRating] = useState(5)
  const [hoverRating, setHoverRating] = useState<number | null>(null)
  const [type, setType] = useState('Feature Request')
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim()) return
    setIsSubmitted(true)
  }

  return (
    <ContentPage
      title="Feedback & Suggestions"
      description="Help us make WhiteScreen.vip better. We review every feature request, bug report, and tool idea."
    >
      {isSubmitted ? (
        <div className="my-8 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-8 text-center text-foreground">
          <CheckCircle className="mx-auto size-12 text-emerald-500 mb-3" />
          <h2 className="text-xl font-semibold !mt-0">Thank you for your feedback!</h2>
          <p className="mt-2 text-muted-foreground text-sm max-w-md mx-auto">
            Your notes help guide what tools and features we build next. We appreciate your support.
          </p>
          <button
            type="button"
            onClick={() => {
              setMessage('')
              setIsSubmitted(false)
            }}
            className="mt-6 text-sm font-medium text-primary hover:underline"
          >
            Submit another note
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-6 not-prose">
          {/* Rating */}
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">How is your experience with WhiteScreen.vip?</label>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(null)}
                  className="p-1 text-muted-foreground hover:scale-110 transition-transform"
                >
                  <Star
                    className={cn(
                      'size-6 transition-colors',
                      (hoverRating ?? rating) >= star
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-muted-foreground/40',
                    )}
                  />
                </button>
              ))}
              <span className="ml-2 text-xs font-mono text-muted-foreground">
                {rating === 5 ? 'Excellent' : rating === 4 ? 'Good' : rating === 3 ? 'Average' : 'Needs work'}
              </span>
            </div>
          </div>

          {/* Feedback Type */}
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Feedback Category</label>
            <div className="flex flex-wrap gap-2">
              {['Feature Request', 'Bug Report', 'New Tool Idea', 'General Comment'].map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setType(category)}
                  className={cn(
                    'rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors',
                    type === category
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'border-border bg-background hover:bg-muted text-foreground',
                  )}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Message */}
          <div className="flex flex-col gap-2">
            <label htmlFor="feedback-message" className="text-sm font-medium">
              Your Message <span className="text-red-500">*</span>
            </label>
            <textarea
              id="feedback-message"
              required
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell us what you'd love to see, or describe any issue you ran into..."
              className="rounded-xl border bg-background p-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>

          {/* Email */}
          <div className="flex flex-col gap-2">
            <label htmlFor="feedback-email" className="text-sm font-medium">
              Email Address <span className="text-xs font-normal text-muted-foreground">(optional, if you&apos;d like a reply)</span>
            </label>
            <input
              id="feedback-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="h-10 rounded-xl border bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>

          <div className="pt-2">
            <ActionButton type="submit" variant="primary" className="w-full sm:w-auto">
              <Send aria-hidden="true" className="size-4" />
              Send Feedback
            </ActionButton>
          </div>
        </form>
      )}

      <h2>Other ways to reach us</h2>
      <p>
        Prefer email? You can also write to us directly at{' '}
        <a href="mailto:hello@whitescreen.vip">hello@whitescreen.vip</a>.
      </p>
    </ContentPage>
  )
}
