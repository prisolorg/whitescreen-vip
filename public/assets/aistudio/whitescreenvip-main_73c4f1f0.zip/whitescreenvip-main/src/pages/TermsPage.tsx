import { ContentPage } from '@/components/content-page'
import Link from 'next/link'

export function TermsPage() {
  return (
    <ContentPage
      title="Terms of Use"
      description="Please review our terms of use before using WhiteScreen.vip tools, simulations, and services."
      updated="October 21, 2026"
    >
      <h2>Acceptance of terms</h2>
      <p>
        By accessing or using WhiteScreen.vip, you agree to be bound by these Terms of Use and our
        associated policies. If you do not agree with any part of these terms, please do not use our
        services.
      </p>

      <h2>Educational and entertainment use</h2>
      <p>
        All screen simulations—including but not limited to update screens, fake video conferences,
        and visual noise effects—are provided exclusively for entertainment, video production, set
        props, and harmless prank purposes.
      </p>
      <ul>
        <li>You agree not to use any simulation to deceive or harm others maliciously.</li>
        <li>
          All product names, trademarks, and registered trademarks displayed in simulations belong to
          their respective owners. WhiteScreen.vip is not affiliated with, endorsed by, or sponsored
          by Microsoft, Apple, Google, or any other trademark owner.
        </li>
      </ul>

      <h2>User responsibility & screen safety</h2>
      <p>
        Displaying static colors or intense high-contrast patterns for extended periods can cause
        temporary image retention or burn-in on susceptible displays (such as OLED panels). You are
        solely responsible for managing display brightness and avoiding prolonged unattended static
        display use.
      </p>

      <h2>Disclaimer of warranties</h2>
      <p>
        WhiteScreen.vip is provided on an “as is” and “as available” basis without any warranties of
        any kind, either express or implied. We do not warrant that our tools will be uninterrupted,
        error-free, or meet medical, calibration, or laboratory standards.
      </p>

      <h2>Limitation of liability</h2>
      <p>
        To the fullest extent permitted by applicable law, WhiteScreen.vip and its maintainers shall
        not be liable for any indirect, incidental, punitive, or consequential damages resulting from
        your use of the site or tools.
      </p>

      <h2>Questions and contact</h2>
      <p>
        If you have any questions regarding these Terms of Use, please{' '}
        <Link href="/contact">contact us</Link> or email hello@whitescreen.vip.
      </p>
    </ContentPage>
  )
}
