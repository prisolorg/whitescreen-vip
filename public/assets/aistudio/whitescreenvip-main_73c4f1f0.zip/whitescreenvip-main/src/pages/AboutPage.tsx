import Link from 'next/link'
import { ContentPage } from '@/components/content-page'

const description =
  'Learn about WhiteScreen.vip, a free and lightweight browser tool for fullscreen white and colored screens.'

export function AboutPage() {
  return (
    <ContentPage title="About Us" description={description}>
      <p>
        WhiteScreen.vip is a simple, focused tool suite that turns any screen into a solid, full-brightness
        color, diagnostic test pattern, visual effect, or screensaver. We built it because most similar
        sites are slow, cluttered with ads, or full of intrusive popups — when all you really want is a clean,
        reliable screen tool, instantly.
      </p>
      <h2>What we believe</h2>
      <ul>
        <li>Tools should load fast and do their job cleanly without friction.</li>
        <li>Your privacy matters: every tool runs entirely client-side in your browser.</li>
        <li>Good design means fewer distractions, zero popups, and reliable keyboard controls.</li>
      </ul>
      <h2>What we offer</h2>
      <p>
        Over 50 free web utilities: solid color light sources, dead pixel and backlight bleed testers,
        screen uniformity checkups, Matrix and flip clock screensavers, Pomodoro and countdown timers,
        and harmless visual props for video producers and sets.
      </p>
      <p>
        Have a suggestion or feature request? <Link href="/feedback">Send us feedback</Link> or{' '}
        <Link href="/contact">get in touch</Link>.
      </p>
    </ContentPage>
  )
}
