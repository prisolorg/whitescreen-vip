import { useState } from 'react'
import { ContentPage } from '@/components/content-page'
import { ActionButton } from '@/components/tool-kit/controls'
import { siteConfig } from '@/lib/site'
import { Send, CheckCircle, Mail } from 'lucide-react'

const description =
  'Contact the WhiteScreen.vip team with feedback, feature ideas, bug reports, or partnership questions.'

export function ContactPage() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [subject, setSubject] = useState('')
  const [message, setMessage] = useState('')
  const [isSent, setIsSent] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim() || !email.trim()) return
    setIsSent(true)
  }

  return (
    <ContentPage title="Contact" description={description}>
      <p>
        We read every message. The fastest way to reach us is by emailing us at{' '}
        <a href={`mailto:${siteConfig.contactEmail}`}>{siteConfig.contactEmail}</a> or submitting the
        form below.
      </p>

      {isSent ? (
        <div className="my-8 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-6 text-center text-foreground not-prose">
          <CheckCircle className="mx-auto size-10 text-emerald-500 mb-2" />
          <h3 className="text-lg font-semibold">Message Received!</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Thank you for reaching out. We typically reply within 1-2 business days.
          </p>
          <button
            type="button"
            onClick={() => {
              setMessage('')
              setSubject('')
              setIsSent(false)
            }}
            className="mt-4 text-xs font-medium text-primary hover:underline"
          >
            Send another message
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="my-6 flex flex-col gap-4 not-prose rounded-2xl border bg-card p-6 shadow-sm">
          <h3 className="font-semibold text-base mb-1">Send us a direct message</h3>
          
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5">
              <label htmlFor="contact-name" className="text-xs font-medium text-muted-foreground">
                Your Name
              </label>
              <input
                id="contact-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Jane Doe"
                className="h-10 rounded-lg border bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label htmlFor="contact-email" className="text-xs font-medium text-muted-foreground">
                Email Address <span className="text-red-500">*</span>
              </label>
              <input
                id="contact-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="h-10 rounded-lg border bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="contact-subject" className="text-xs font-medium text-muted-foreground">
              Subject
            </label>
            <input
              id="contact-subject"
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Question about screen tests or a tool suggestion..."
              className="h-10 rounded-lg border bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="contact-message" className="text-xs font-medium text-muted-foreground">
              Message <span className="text-red-500">*</span>
            </label>
            <textarea
              id="contact-message"
              required
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="How can we help you?"
              className="rounded-lg border bg-background p-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>

          <div className="pt-2">
            <ActionButton type="submit" variant="primary">
              <Send aria-hidden="true" className="size-4" />
              Send Message
            </ActionButton>
          </div>
        </form>
      )}

      <h2>Reporting a problem</h2>
      <p>If something isn’t working as expected, it helps to include:</p>
      <ul>
        <li>Your device, monitor model, and operating system</li>
        <li>Your web browser and version</li>
        <li>Steps to reproduce what happened</li>
      </ul>
      <p>We test across Windows, macOS, Android, iOS, Chrome, Edge, Safari, and Firefox.</p>
    </ContentPage>
  )
}
