import { ContentPage } from '@/components/content-page'

const description =
  'The WhiteScreen.vip disclaimer covers use of the screen tool, health considerations, and limitations of liability.'

export function DisclaimerPage() {
  return (
    <ContentPage title="Disclaimer" description={description} updated="October 21, 2026">
      <h2>General use</h2>
      <p>
        WhiteScreen.vip is provided “as is” for general, diagnostic, and informational purposes. While
        helpful for dead pixel checks and monitor inspection, we make no guarantees about suitability
        for calibrated medical or safety-critical color matching.
      </p>
      <h2>Health and visual comfort</h2>
      <p>
        Solid bright colors at maximum display brightness can cause visual fatigue. Take regular breaks
        (e.g. the 20-20-20 rule) and lower display brightness if you experience eye discomfort. If you
        have light sensitivity or conditions triggered by flashing patterns, use high-speed effect tools
        with caution.
      </p>
      <h2>Display hardware care</h2>
      <p>
        Displaying static content for hours on end may contribute to image retention on OLED and plasma
        displays. Enable dynamic screensavers or turn off screens when leaving displays unattended.
      </p>
      <h2>Trademarks and simulations</h2>
      <p>
        All operating system simulations and video call interfaces are intended strictly for video production,
        set dressing, and entertainment. Trademarks belong to their respective copyright holders.
      </p>
      <h2>Limitation of liability</h2>
      <p>
        We are not liable for any damages or losses arising from the use of this website or its tools.
      </p>
    </ContentPage>
  )
}
