'use client'

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react'

export type LanguageCode =
  | 'en'
  | 'es'
  | 'pt-br'
  | 'de'
  | 'fr'
  | 'it'
  | 'nl'
  | 'id'
  | 'tr'

export type LanguageInfo = {
  code: LanguageCode
  displayCode: string
  name: string
  nativeName: string
  formattedLabel: string
  dir: 'ltr' | 'rtl'
}

export const LANGUAGES: readonly LanguageInfo[] = [
  { code: 'en', displayCode: 'EN', name: 'English', nativeName: 'English', formattedLabel: 'EN — English', dir: 'ltr' },
  { code: 'es', displayCode: 'ES', name: 'Spanish', nativeName: 'Español', formattedLabel: 'ES — Español', dir: 'ltr' },
  { code: 'pt-br', displayCode: 'PT-BR', name: 'Portuguese (Brazil)', nativeName: 'Português (Brasil)', formattedLabel: 'PT-BR — Português (Brasil)', dir: 'ltr' },
  { code: 'de', displayCode: 'DE', name: 'German', nativeName: 'Deutsch', formattedLabel: 'DE — Deutsch', dir: 'ltr' },
  { code: 'fr', displayCode: 'FR', name: 'French', nativeName: 'Français', formattedLabel: 'FR — Français', dir: 'ltr' },
  { code: 'it', displayCode: 'IT', name: 'Italian', nativeName: 'Italiano', formattedLabel: 'IT — Italiano', dir: 'ltr' },
  { code: 'nl', displayCode: 'NL', name: 'Dutch', nativeName: 'Nederlands', formattedLabel: 'NL — Nederlands', dir: 'ltr' },
  { code: 'id', displayCode: 'ID', name: 'Indonesian', nativeName: 'Bahasa Indonesia', formattedLabel: 'ID — Bahasa Indonesia', dir: 'ltr' },
  { code: 'tr', displayCode: 'TR', name: 'Turkish', nativeName: 'Türkçe', formattedLabel: 'TR — Türkçe', dir: 'ltr' },
]

export const TRANSLATIONS: Record<LanguageCode, Record<string, string>> = {
  en: {
    home: 'Home',
    screenTests: 'Screen Tests',
    effects: 'Effects',
    screensavers: 'Screensavers',
    fakeScreens: 'Fake Screens',
    otherTools: 'Other Tools',
    guides: 'Guides',
    feedback: 'Feedback',
    searchTools: 'Search tools, e.g. "dead pixel"',
    allTools: 'All tools',
    menu: 'Menu',
    closeMenu: 'Close menu',

    openFullscreen: 'Open fullscreen',
    fullscreen: 'Fullscreen',
    exitFullscreen: 'Exit fullscreen',
    customColor: 'Custom',
    resolution: 'Resolution',
    customResolution: 'Custom resolution',
    width: 'Width',
    height: 'Height',
    downloadImage: 'Download Image',
    downloading: 'Downloading...',
    downloaded: 'Downloaded!',
    shortcuts: 'Shortcuts',
    shortcutF: 'fullscreen',
    shortcutNumbers: 'pick color',
    shortcutArrows: 'cycle',
    shortcutEsc: 'exit',
    exitHint: 'Press Esc or double-click to exit · ← → to change color',

    white: 'White',
    black: 'Black',
    red: 'Red',
    green: 'Green',
    blue: 'Blue',
    yellow: 'Yellow',
    orange: 'Orange',
    pink: 'Pink',
    purple: 'Purple',
    cyan: 'Cyan',
    magenta: 'Magenta',
    gray: 'Gray',

    heroTitle: 'White Screen',
    heroIntro:
      'Turn your display into a clean, bright white screen in one click. Use it as a light source, to test for dead pixels, or to clean your monitor — or switch to any other color.',

    preset480p: '480p SD',
    preset720p: '720p HD',
    preset1080p: '1080p FHD',
    preset1440p: '1440p QHD',
    preset2k: '2K DCI',
    preset4k: '4K UHD',
    preset8k: '8K UHD-2',

    benefitsTitle: 'Why use WhiteScreen.vip',
    useCasesTitle: 'Common use cases',
    howToUseTitle: 'How to use the white screen',
    faqTitle: 'Frequently asked questions',
    colorScreensTitle: 'Explore other color screens',

    footerDesc:
      'Free screen tests, effects, screensavers and utilities that run entirely in your browser.',
    about: 'About',
    contact: 'Contact',
    privacyPolicy: 'Privacy Policy',
    terms: 'Terms of Use',
    disclaimer: 'Disclaimer',
    copyright: 'WhiteScreen.vip. All rights reserved.',
  },

  es: {
    home: 'Inicio',
    screenTests: 'Pruebas de pantalla',
    effects: 'Efectos visuales',
    screensavers: 'Salvapantallas',
    fakeScreens: 'Simulaciones',
    otherTools: 'Otras herramientas',
    guides: 'Guías',
    feedback: 'Comentarios',
    searchTools: 'Buscar herramientas, ej. "píxel muerto"',
    allTools: 'Todas las herramientas',
    menu: 'Menú',
    closeMenu: 'Cerrar menú',

    openFullscreen: 'Abrir pantalla completa',
    fullscreen: 'Pantalla completa',
    exitFullscreen: 'Salir de pantalla completa',
    customColor: 'Personalizado',
    resolution: 'Resolución',
    customResolution: 'Resolución personalizada',
    width: 'Ancho',
    height: 'Alto',
    downloadImage: 'Descargar imagen',
    downloading: 'Descargando...',
    downloaded: '¡Descargado!',
    shortcuts: 'Atajos',
    shortcutF: 'pantalla completa',
    shortcutNumbers: 'elegir color',
    shortcutArrows: 'cambiar',
    shortcutEsc: 'salir',
    exitHint: 'Presione Esc o doble clic para salir · ← → para cambiar color',

    white: 'Blanco',
    black: 'Negro',
    red: 'Rojo',
    green: 'Verde',
    blue: 'Azul',
    yellow: 'Amarillo',
    orange: 'Naranja',
    pink: 'Rosa',
    purple: 'Púrpura',
    cyan: 'Cian',
    magenta: 'Magenta',
    gray: 'Gris',

    heroTitle: 'Pantalla Blanca (White Screen)',
    heroIntro:
      'Convierte tu pantalla en una superficie blanca, limpia y brillante con un solo clic. Ideal como fuente de luz, para detectar píxeles muertos o limpiar tu monitor.',

    preset480p: '480p SD',
    preset720p: '720p HD',
    preset1080p: '1080p FHD',
    preset1440p: '1440p QHD',
    preset2k: '2K DCI',
    preset4k: '4K UHD',
    preset8k: '8K UHD-2',

    benefitsTitle: 'Por qué usar WhiteScreen.vip',
    useCasesTitle: 'Usos comunes',
    howToUseTitle: 'Cómo usar la pantalla blanca',
    faqTitle: 'Preguntas frecuentes',
    colorScreensTitle: 'Explorar otras pantallas de colores',

    footerDesc:
      'Herramientas gratuitas de prueba de pantalla, efectos, salvapantallas y utilidades 100% en tu navegador.',
    about: 'Nosotros',
    contact: 'Contacto',
    privacyPolicy: 'Política de privacidad',
    terms: 'Términos de uso',
    disclaimer: 'Descargo de responsabilidad',
    copyright: 'WhiteScreen.vip. Todos los derechos reservados.',
  },

  'pt-br': {
    home: 'Início',
    screenTests: 'Testes de tela',
    effects: 'Efeitos visuais',
    screensavers: 'Protetores de tela',
    fakeScreens: 'Simulações',
    otherTools: 'Outras ferramentas',
    guides: 'Guias',
    feedback: 'Feedback',
    searchTools: 'Pesquisar ferramentas...',
    allTools: 'Todas as ferramentas',
    menu: 'Menu',
    closeMenu: 'Fechar menu',

    openFullscreen: 'Abrir tela cheia',
    fullscreen: 'Tela cheia',
    exitFullscreen: 'Sair de tela cheia',
    customColor: 'Personalizado',
    resolution: 'Resolução',
    customResolution: 'Resolução personalizada',
    width: 'Largura',
    height: 'Altura',
    downloadImage: 'Baixar imagem',
    downloading: 'Baixando...',
    downloaded: 'Baixado com sucesso!',
    shortcuts: 'Atalhos',
    shortcutF: 'tela cheia',
    shortcutNumbers: 'escolher cor',
    shortcutArrows: 'alternar',
    shortcutEsc: 'sair',
    exitHint: 'Pressione Esc ou clique duas vezes para sair',

    white: 'Branco',
    black: 'Preto',
    red: 'Vermelho',
    green: 'Verde',
    blue: 'Azul',
    yellow: 'Amarelo',
    orange: 'Laranja',
    pink: 'Rosa',
    purple: 'Roxo',
    cyan: 'Ciano',
    magenta: 'Magenta',
    gray: 'Cinza',

    heroTitle: 'Tela Branca (White Screen)',
    heroIntro:
      'Transforme sua tela em um fundo branco limpo e brilhante com apenas um clique. Use como fonte de luz, teste de pixels mortos ou limpeza de tela.',

    preset480p: '480p SD',
    preset720p: '720p HD',
    preset1080p: '1080p FHD',
    preset1440p: '1440p QHD',
    preset2k: '2K DCI',
    preset4k: '4K UHD',
    preset8k: '8K UHD-2',

    benefitsTitle: 'Por que usar o WhiteScreen.vip',
    useCasesTitle: 'Usos mais comuns',
    howToUseTitle: 'Como usar a tela branca',
    faqTitle: 'Perguntas frequentes',
    colorScreensTitle: 'Ver outras cores de tela',

    footerDesc:
      'Testes de tela, efeitos visuais e ferramentas gratuitas que rodam direto no navegador.',
    about: 'Sobre nós',
    contact: 'Contato',
    privacyPolicy: 'Política de privacidade',
    terms: 'Termos de uso',
    disclaimer: 'Aviso legal',
    copyright: 'WhiteScreen.vip. Todos os direitos reservados.',
  },

  de: {
    home: 'Startseite',
    screenTests: 'Bildschirmtests',
    effects: 'Visuelle Effekte',
    screensavers: 'Bildschirmschoner',
    fakeScreens: 'Simulationen',
    otherTools: 'Weitere Tools',
    guides: 'Anleitungen',
    feedback: 'Feedback',
    searchTools: 'Tools durchsuchen...',
    allTools: 'Alle Tools',
    menu: 'Menü',
    closeMenu: 'Menü schließen',

    openFullscreen: 'Vollbild öffnen',
    fullscreen: 'Vollbild',
    exitFullscreen: 'Vollbild beenden',
    customColor: 'Benutzerdefiniert',
    resolution: 'Auflösung',
    customResolution: 'Eigene Auflösung',
    width: 'Breite',
    height: 'Höhe',
    downloadImage: 'Bild herunterladen',
    downloading: 'Wird heruntergeladen...',
    downloaded: 'Heruntergeladen!',
    shortcuts: 'Tastenkürzel',
    shortcutF: 'Vollbild',
    shortcutNumbers: 'Farbe wählen',
    shortcutArrows: 'wechseln',
    shortcutEsc: 'beenden',
    exitHint: 'Esc drücken oder doppelklicken zum Beenden · ← → für Farbwechsel',

    white: 'Weiß',
    black: 'Schwarz',
    red: 'Rot',
    green: 'Grün',
    blue: 'Blau',
    yellow: 'Gelb',
    orange: 'Orange',
    pink: 'Rosa',
    purple: 'Lila',
    cyan: 'Cyan',
    magenta: 'Magenta',
    gray: 'Grau',

    heroTitle: 'Weißer Bildschirm (White Screen)',
    heroIntro:
      'Verwandeln Sie Ihren Monitor mit einem Klick in einen sauberen, hellen weißen Bildschirm. Ideal als Lichtquelle, zum Erkennen von Pixelfehlern oder zum Reinigen.',

    preset480p: '480p SD',
    preset720p: '720p HD',
    preset1080p: '1080p FHD',
    preset1440p: '1440p QHD',
    preset2k: '2K DCI',
    preset4k: '4K UHD',
    preset8k: '8K UHD-2',

    benefitsTitle: 'Vorteile von WhiteScreen.vip',
    useCasesTitle: 'Typische Einsatzzwecke',
    howToUseTitle: 'Bedienungsanleitung',
    faqTitle: 'Häufig gestellte Fragen',
    colorScreensTitle: 'Weitere Farben entdecken',

    footerDesc:
      'Kostenlose Bildschirmtests, Bildschirmschoner und Tools direkt im Webbrowser ohne Installation.',
    about: 'Über uns',
    contact: 'Kontakt',
    privacyPolicy: 'Datenschutz',
    terms: 'Nutzungsbedingungen',
    disclaimer: 'Haftungsausschluss',
    copyright: 'WhiteScreen.vip. Alle Rechte vorbehalten.',
  },

  fr: {
    home: 'Accueil',
    screenTests: "Tests d'écran",
    effects: 'Effets visuels',
    screensavers: 'Écrans de veille',
    fakeScreens: 'Simulations',
    otherTools: 'Autres outils',
    guides: 'Guides',
    feedback: 'Avis',
    searchTools: 'Rechercher des outils...',
    allTools: 'Tous les outils',
    menu: 'Menu',
    closeMenu: 'Fermer le menu',

    openFullscreen: 'Plein écran',
    fullscreen: 'Plein écran',
    exitFullscreen: 'Quitter plein écran',
    customColor: 'Personnalisé',
    resolution: 'Résolution',
    customResolution: 'Résolution personnalisée',
    width: 'Largeur',
    height: 'Hauteur',
    downloadImage: "Télécharger l'image",
    downloading: 'Téléchargement...',
    downloaded: 'Téléchargé !',
    shortcuts: 'Raccourcis',
    shortcutF: 'plein écran',
    shortcutNumbers: 'choisir couleur',
    shortcutArrows: 'défiler',
    shortcutEsc: 'quitter',
    exitHint: 'Appuyez sur Échap ou double-cliquez pour quitter',

    white: 'Blanc',
    black: 'Noir',
    red: 'Rouge',
    green: 'Vert',
    blue: 'Bleu',
    yellow: 'Jaune',
    orange: 'Orange',
    pink: 'Rose',
    purple: 'Violet',
    cyan: 'Cyan',
    magenta: 'Magenta',
    gray: 'Gris',

    heroTitle: 'Écran Blanc (White Screen)',
    heroIntro:
      'Transformez votre écran en un fond blanc propre et lumineux en un clic. Utilisable comme source de lumière, pour repérer les pixels morts ou nettoyer votre moniteur.',

    preset480p: '480p SD',
    preset720p: '720p HD',
    preset1080p: '1080p FHD',
    preset1440p: '1440p QHD',
    preset2k: '2K DCI',
    preset4k: '4K UHD',
    preset8k: '8K UHD-2',

    benefitsTitle: 'Pourquoi choisir WhiteScreen.vip',
    useCasesTitle: 'Cas d’usage courants',
    howToUseTitle: 'Comment utiliser l’écran blanc',
    faqTitle: 'Foire aux questions',
    colorScreensTitle: 'Découvrir les autres couleurs',

    footerDesc:
      'Outils gratuits de test d’écran, effets visuels et écrans de veille directement dans votre navigateur.',
    about: 'À propos',
    contact: 'Contact',
    privacyPolicy: 'Politique de confidentialité',
    terms: 'Conditions d’utilisation',
    disclaimer: 'Avertissement',
    copyright: 'WhiteScreen.vip. Tous droits réservés.',
  },

  it: {
    home: 'Home',
    screenTests: 'Test dello schermo',
    effects: 'Effetti visivi',
    screensavers: 'Salvaschermo',
    fakeScreens: 'Simulazioni',
    otherTools: 'Altri strumenti',
    guides: 'Guide',
    feedback: 'Feedback',
    searchTools: 'Cerca strumenti...',
    allTools: 'Tutti gli strumenti',
    menu: 'Menu',
    closeMenu: 'Chiudi menu',

    openFullscreen: 'Apri a schermo intero',
    fullscreen: 'Schermo intero',
    exitFullscreen: 'Esci da schermo intero',
    customColor: 'Personalizzato',
    resolution: 'Risoluzione',
    customResolution: 'Risoluzione personalizzata',
    width: 'Larghezza',
    height: 'Altezza',
    downloadImage: 'Scarica immagine',
    downloading: 'Scaricamento...',
    downloaded: 'Scaricato!',
    shortcuts: 'Scorciatoie',
    shortcutF: 'schermo intero',
    shortcutNumbers: 'scegli colore',
    shortcutArrows: 'cambia',
    shortcutEsc: 'esci',
    exitHint: 'Premi Esc o fai doppio clic per uscire · ← → per cambiare colore',

    white: 'Bianco',
    black: 'Nero',
    red: 'Rosso',
    green: 'Verde',
    blue: 'Blu',
    yellow: 'Giallo',
    orange: 'Arancione',
    pink: 'Rosa',
    purple: 'Viola',
    cyan: 'Ciano',
    magenta: 'Magenta',
    gray: 'Grigio',

    heroTitle: 'Schermo Bianco (White Screen)',
    heroIntro:
      'Trasforma il tuo display in uno schermo bianco brillante e pulito con un solo clic. Ideale come fonte di luce, per rilevare pixel bruciati o pulire il monitor.',

    preset480p: '480p SD',
    preset720p: '720p HD',
    preset1080p: '1080p FHD',
    preset1440p: '1440p QHD',
    preset2k: '2K DCI',
    preset4k: '4K UHD',
    preset8k: '8K UHD-2',

    benefitsTitle: 'Perché usare WhiteScreen.vip',
    useCasesTitle: 'Usi comuni',
    howToUseTitle: 'Come usare lo schermo bianco',
    faqTitle: 'Domande frequenti',
    colorScreensTitle: 'Esplora altri schermi colorati',

    footerDesc:
      'Test di visualizzazione, effetti visivi e utilità gratuiti eseguiti direttamente nel browser.',
    about: 'Chi siamo',
    contact: 'Contatto',
    privacyPolicy: 'Informativa sulla privacy',
    terms: 'Termini di utilizzo',
    disclaimer: 'Dichiarazione di non responsabilità',
    copyright: 'WhiteScreen.vip. Tutti i diritti riservati.',
  },

  nl: {
    home: 'Home',
    screenTests: 'Schermtests',
    effects: 'Visuele effecten',
    screensavers: 'Schermbeveiligingen',
    fakeScreens: 'Simulaties',
    otherTools: 'Andere tools',
    guides: 'Gidsen',
    feedback: 'Feedback',
    searchTools: 'Zoek tools...',
    allTools: 'Alle tools',
    menu: 'Menu',
    closeMenu: 'Menu sluiten',

    openFullscreen: 'Volledig scherm openen',
    fullscreen: 'Volledig scherm',
    exitFullscreen: 'Volledig scherm sluiten',
    customColor: 'Aangepast',
    resolution: 'Resolutie',
    customResolution: 'Aangepaste resolutie',
    width: 'Breedte',
    height: 'Hoogte',
    downloadImage: 'Afbeelding downloaden',
    downloading: 'Downloaden...',
    downloaded: 'Gedownload!',
    shortcuts: 'Sneltoetsen',
    shortcutF: 'volledig scherm',
    shortcutNumbers: 'kies kleur',
    shortcutArrows: 'wisselen',
    shortcutEsc: 'verlaten',
    exitHint: 'Druk op Esc of dubbelklik om te sluiten · ← → om van kleur te wisselen',

    white: 'Wit',
    black: 'Zwart',
    red: 'Rood',
    green: 'Groen',
    blue: 'Blauw',
    yellow: 'Geel',
    orange: 'Oranje',
    pink: 'Roze',
    purple: 'Paars',
    cyan: 'Cyaan',
    magenta: 'Magenta',
    gray: 'Grijs',

    heroTitle: 'Wit Scherm (White Screen)',
    heroIntro:
      'Verander je scherm in één klik in een helder, wit scherm. Ideaal als lichtbron of om dode pixels te controleren.',

    preset480p: '480p SD',
    preset720p: '720p HD',
    preset1080p: '1080p FHD',
    preset1440p: '1440p QHD',
    preset2k: '2K DCI',
    preset4k: '4K UHD',
    preset8k: '8K UHD-2',

    benefitsTitle: 'Waarom WhiteScreen.vip gebruiken',
    useCasesTitle: 'Veelvoorkomende toepassingen',
    howToUseTitle: 'Hoe het witte scherm te gebruiken',
    faqTitle: 'Veelgestelde vragen',
    colorScreensTitle: 'Ontdek andere gekleurde schermen',

    footerDesc:
      'Gratis schermtests, visuele effecten en utilities die volledig in uw browser draaien.',
    about: 'Over ons',
    contact: 'Contact',
    privacyPolicy: 'Privacybeleid',
    terms: 'Gebruiksvoorwaarden',
    disclaimer: 'Disclaimer',
    copyright: 'WhiteScreen.vip. Alle rechten voorbehouden.',
  },

  id: {
    home: 'Beranda',
    screenTests: 'Tes Layar',
    effects: 'Efek Visual',
    screensavers: 'Screensaver',
    fakeScreens: 'Simulasi',
    otherTools: 'Alat Lainnya',
    guides: 'Panduan',
    feedback: 'Masukan',
    searchTools: 'Cari alat...',
    allTools: 'Semua Alat',
    menu: 'Menu',
    closeMenu: 'Tutup Menu',

    openFullscreen: 'Buka Layar Penuh',
    fullscreen: 'Layar Penuh',
    exitFullscreen: 'Keluar Layar Penuh',
    customColor: 'Kustom',
    resolution: 'Resolusi',
    customResolution: 'Resolusi Kustom',
    width: 'Lebar',
    height: 'Tinggi',
    downloadImage: 'Unduh Gambar',
    downloading: 'Mengunduh...',
    downloaded: 'Berhasil Diunduh!',
    shortcuts: 'Pintasan',
    shortcutF: 'layar penuh',
    shortcutNumbers: 'pilih warna',
    shortcutArrows: 'ganti warna',
    shortcutEsc: 'keluar',
    exitHint: 'Tekan Esc atau klik dua kali untuk keluar · ← → untuk ganti warna',

    white: 'Putih',
    black: 'Hitam',
    red: 'Merah',
    green: 'Hijau',
    blue: 'Biru',
    yellow: 'Kuning',
    orange: 'Oranye',
    pink: 'Merah Muda',
    purple: 'Ungu',
    cyan: 'Sian',
    magenta: 'Magenta',
    gray: 'Abu-abu',

    heroTitle: 'Layar Putih (White Screen)',
    heroIntro:
      'Ubah layar Anda menjadi layar putih bersih dan terang hanya dengan satu klik. Bagus untuk sumber cahaya, uji piksel mati, atau membersihkan monitor.',

    preset480p: '480p SD',
    preset720p: '720p HD',
    preset1080p: '1080p FHD',
    preset1440p: '1440p QHD',
    preset2k: '2K DCI',
    preset4k: '4K UHD',
    preset8k: '8K UHD-2',

    benefitsTitle: 'Mengapa menggunakan WhiteScreen.vip',
    useCasesTitle: 'Penggunaan Umum',
    howToUseTitle: 'Cara Menggunakan Layar Putih',
    faqTitle: 'Pertanyaan yang Sering Diajukan',
    colorScreensTitle: 'Jelajahi layar warna lainnya',

    footerDesc:
      'Uji layar gratis, efek visual, dan screensaver yang berjalan langsung di browser Anda.',
    about: 'Tentang Kami',
    contact: 'Kontak',
    privacyPolicy: 'Kebijakan Privasi',
    terms: 'Ketentuan Penggunaan',
    disclaimer: 'Penyangkalan',
    copyright: 'WhiteScreen.vip. Hak cipta dilindungi.',
  },

  tr: {
    home: 'Ana Sayfa',
    screenTests: 'Ekran Testleri',
    effects: 'Görsel Efektler',
    screensavers: 'Ekran Koruyucular',
    fakeScreens: 'Simülasyonlar',
    otherTools: 'Diğer Araçlar',
    guides: 'Rehberler',
    feedback: 'Geri Bildirim',
    searchTools: 'Araçları ara...',
    allTools: 'Tüm Araçlar',
    menu: 'Menü',
    closeMenu: 'Menüyü Kapat',

    openFullscreen: 'Tam Ekran Aç',
    fullscreen: 'Tam Ekran',
    exitFullscreen: 'Tam Ekrandan Çık',
    customColor: 'Özel Renk',
    resolution: 'Çözünürlük',
    customResolution: 'Özel Çözünürlük',
    width: 'Genişlik',
    height: 'Yükseklik',
    downloadImage: 'Resmi İndir',
    downloading: 'İndiriliyor...',
    downloaded: 'İndirildi!',
    shortcuts: 'Kısayollar',
    shortcutF: 'tam ekran',
    shortcutNumbers: 'renk seç',
    shortcutArrows: 'değiştir',
    shortcutEsc: 'çıkış',
    exitHint: 'Çıkmak için Esc tuşuna basın veya çift tıklayın · Renk değiştirmek için ← → tuşlarını kullanın',

    white: 'Beyaz',
    black: 'Siyah',
    red: 'Kırmızı',
    green: 'Yeşil',
    blue: 'Mavi',
    yellow: 'Sarı',
    orange: 'Turuncu',
    pink: 'Pembe',
    purple: 'Mor',
    cyan: 'Camgöbeği',
    magenta: 'Macenta',
    gray: 'Gri',

    heroTitle: 'Beyaz Ekran (White Screen)',
    heroIntro:
      'Tek tıkla ekranınızı temiz ve parlak bir beyaz ekrana dönüştürün. Ölü piksel testi, ışık kaynağı veya ekran temizliği için kullanın.',

    preset480p: '480p SD',
    preset720p: '720p HD',
    preset1080p: '1080p FHD',
    preset1440p: '1440p QHD',
    preset2k: '2K DCI',
    preset4k: '4K UHD',
    preset8k: '8K UHD-2',

    benefitsTitle: 'Neden WhiteScreen.vip',
    useCasesTitle: 'Yaygın Kullanım Alanları',
    howToUseTitle: 'Beyaz Ekran Nasıl Kullanılır',
    faqTitle: 'Sıkça Sorulan Sorular',
    colorScreensTitle: 'Diğer renkli ekranları keşfedin',

    footerDesc:
      'Tamamen tarayıcınızda çalışan ücretsiz ekran testleri, efektler ve ekran koruyucular.',
    about: 'Hakkımızda',
    contact: 'İletişim',
    privacyPolicy: 'Gizlilik Politikası',
    terms: 'Kullanım Koşulları',
    disclaimer: 'Sorumluluk Reddi',
    copyright: 'WhiteScreen.vip. Tüm hakları saklıdır.',
  },
}

interface I18nContextType {
  language: LanguageCode
  setLanguage: (lang: LanguageCode) => void
  t: (key: string, fallback?: string) => string
  dir: 'ltr' | 'rtl'
  languageInfo: LanguageInfo
}

const I18nContext = createContext<I18nContextType>({
  language: 'en',
  setLanguage: () => {},
  t: (key: string, fallback?: string) => fallback ?? key,
  dir: 'ltr',
  languageInfo: LANGUAGES[0],
})

const STORAGE_KEY = 'whitescreen_lang'

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY) as LanguageCode | null
        if (saved && LANGUAGES.some((l) => l.code === saved)) {
          return saved
        }
      } catch {
        // Fallback to en if localStorage is blocked
      }
    }
    return 'en'
  })

  const currentInfo = LANGUAGES.find((l) => l.code === language) ?? LANGUAGES[0]

  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.lang = language
      document.documentElement.dir = currentInfo.dir
    }
  }, [language, currentInfo.dir])

  const setLanguage = useCallback((newLang: LanguageCode) => {
    setLanguageState(newLang)
    try {
      localStorage.setItem(STORAGE_KEY, newLang)
    } catch {
      // Ignore storage errors in private browsing
    }
  }, [])

  const t = useCallback(
    (key: string, fallback?: string) => {
      const langDict = TRANSLATIONS[language]
      if (langDict && langDict[key]) {
        return langDict[key]
      }
      // Fallback to English
      const enDict = TRANSLATIONS.en
      if (enDict && enDict[key]) {
        return enDict[key]
      }
      return fallback ?? key
    },
    [language],
  )

  return (
    <I18nContext.Provider
      value={{
        language,
        setLanguage,
        t,
        dir: currentInfo.dir,
        languageInfo: currentInfo,
      }}
    >
      {children}
    </I18nContext.Provider>
  )
}

export function useTranslation() {
  return useContext(I18nContext)
}
