'use client'

import { useId, useMemo, useRef, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Search, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { TOOLS, toolPath, type Tool } from '@/lib/tools'
import { getCategory } from '@/lib/tool-categories'
import { ToolIcon } from './tool-card'

const MAX_RESULTS = 8

export function searchTools(query: string): Tool[] {
  const terms = query.toLowerCase().trim().split(/\s+/).filter(Boolean)
  if (terms.length === 0) return []
  const scored = TOOLS.map((tool) => {
    const name = tool.name.toLowerCase()
    const category = getCategory(tool.category).name.toLowerCase()
    const keywords = tool.keywords.join(' ').toLowerCase()
    const description = tool.description.toLowerCase()
    let score = 0
    for (const term of terms) {
      if (name.includes(term)) score += name.startsWith(term) ? 6 : 4
      else if (keywords.includes(term)) score += 3
      else if (category.includes(term)) score += 2
      else if (description.includes(term)) score += 1
      else return { tool, score: 0 }
    }
    return { tool, score }
  })
  return scored
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .map((item) => item.tool)
}

type ToolSearchProps = {
  size?: 'default' | 'large'
  placeholder?: string
  className?: string
  onNavigate?: () => void
  autoFocus?: boolean
}

export function ToolSearch({
  size = 'default',
  placeholder = 'Search tools, e.g. “dead pixel” or “timer”',
  className,
  onNavigate,
  autoFocus,
}: ToolSearchProps) {
  const router = useRouter()
  const listId = useId()
  const inputId = useId()
  const [query, setQuery] = useState('')
  const [isOpen, setIsOpen] = useState(false)
  const [activeIndex, setActiveIndex] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)

  const results = useMemo(() => searchTools(query).slice(0, MAX_RESULTS), [query])
  const showPanel = isOpen && query.trim().length > 0

  const go = (tool: Tool) => {
    setIsOpen(false)
    setQuery('')
    onNavigate?.()
    router.push(toolPath(tool.slug))
  }

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.nativeEvent.isComposing || event.keyCode === 229) return
    if (event.key === 'ArrowDown') {
      event.preventDefault()
      setIsOpen(true)
      setActiveIndex((index) => Math.min(index + 1, results.length - 1))
    } else if (event.key === 'ArrowUp') {
      event.preventDefault()
      setActiveIndex((index) => Math.max(index - 1, 0))
    } else if (event.key === 'Enter') {
      const tool = results[activeIndex]
      if (tool) {
        event.preventDefault()
        go(tool)
      }
    } else if (event.key === 'Escape') {
      setIsOpen(false)
    }
  }

  return (
    <div
      ref={containerRef}
      className={cn('relative w-full', className)}
      onBlur={(event) => {
        if (!containerRef.current?.contains(event.relatedTarget as Node)) setIsOpen(false)
      }}
    >
      <label htmlFor={inputId} className="sr-only">
        Search tools
      </label>
      <div className="relative">
        <Search
          className={cn(
            'pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground',
            size === 'large' ? 'size-5' : 'size-4',
          )}
          aria-hidden="true"
        />
        <input
          id={inputId}
          type="search"
          role="combobox"
          aria-expanded={showPanel}
          aria-controls={listId}
          aria-autocomplete="list"
          aria-activedescendant={
            showPanel && results[activeIndex] ? `${listId}-${results[activeIndex].slug}` : undefined
          }
          autoComplete="off"
          autoFocus={autoFocus}
          value={query}
          placeholder={placeholder}
          onChange={(event) => {
            setQuery(event.target.value)
            setActiveIndex(0)
            setIsOpen(true)
          }}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          className={cn(
            'w-full rounded-xl border bg-background pr-10 shadow-sm outline-none transition-shadow placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring [&::-webkit-search-cancel-button]:hidden',
            size === 'large' ? 'h-14 pl-11 text-base' : 'h-10 pl-10 text-sm',
          )}
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery('')}
            className="absolute right-2 top-1/2 inline-flex size-7 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Clear search"
          >
            <X className="size-4" aria-hidden="true" />
          </button>
        )}
      </div>

      {showPanel && (
        <div className="absolute inset-x-0 top-full z-50 mt-2 overflow-hidden rounded-xl border bg-popover text-left shadow-lg">
          {results.length > 0 ? (
            <ul id={listId} role="listbox" aria-label="Matching tools" className="max-h-96 overflow-y-auto p-1.5">
              {results.map((tool, index) => (
                <li
                  key={tool.slug}
                  id={`${listId}-${tool.slug}`}
                  role="option"
                  aria-selected={index === activeIndex}
                >
                  <Link
                    href={toolPath(tool.slug)}
                    tabIndex={-1}
                    onMouseEnter={() => setActiveIndex(index)}
                    onClick={() => {
                      setIsOpen(false)
                      setQuery('')
                      onNavigate?.()
                    }}
                    className={cn(
                      'flex items-center gap-3 rounded-lg p-2 text-sm',
                      index === activeIndex && 'bg-accent',
                    )}
                  >
                    <ToolIcon tool={tool} className="size-8" />
                    <span className="min-w-0">
                      <span className="block font-medium">{tool.name}</span>
                      <span className="block truncate text-xs text-muted-foreground">
                        {getCategory(tool.category).name}
                      </span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <div id={listId} className="p-5 text-sm">
              <p className="font-medium">{`No tools match “${query.trim()}”.`}</p>
              <p className="mt-1 text-muted-foreground">
                Try a broader term like “screen”, “test”, “clock” or “update”, or{' '}
                <Link href="/tools" className="font-medium text-foreground underline underline-offset-4">
                  browse all tools
                </Link>
                .
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
