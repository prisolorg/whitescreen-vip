'use client'

import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { ChevronDown, Menu, Search, X, Monitor } from 'lucide-react'
import { cn } from '@/lib/utils'
import { getToolsByCategory, toolPath, type Tool } from '@/lib/tools'
import type { ToolCategoryId } from '@/lib/tool-categories'
import { ToolIcon } from './tool-card'
import { ToolSearch } from './tool-search'
import { useTranslation } from '@/lib/i18n'
import { LanguageSelector } from './language-selector'

type NavGroup = {
  id: string
  translationKey: string
  defaultLabel: string
  href: string
  sections: { titleKey: string; defaultTitle: string; category: ToolCategoryId }[]
}

export const NAV_GROUPS: NavGroup[] = [
  {
    id: 'screen-tests',
    translationKey: 'screenTests',
    defaultLabel: 'Screen Tests',
    href: '/tools#screen-tests',
    sections: [{ titleKey: 'screenTests', defaultTitle: 'Screen tests & colors', category: 'screen-tests' }],
  },
  {
    id: 'effects',
    translationKey: 'effects',
    defaultLabel: 'Effects',
    href: '/tools#effects',
    sections: [
      { titleKey: 'effects', defaultTitle: 'Visual effects', category: 'effects' },
      { titleKey: 'screensavers', defaultTitle: 'Screensavers', category: 'screensavers' },
    ],
  },
  {
    id: 'fake-screens',
    translationKey: 'fakeScreens',
    defaultLabel: 'Fake Screens',
    href: '/tools#fake-screens',
    sections: [{ titleKey: 'fakeScreens', defaultTitle: 'Simulations', category: 'fake-screens' }],
  },
  {
    id: 'utilities',
    translationKey: 'otherTools',
    defaultLabel: 'Other Tools',
    href: '/tools#utilities',
    sections: [{ titleKey: 'otherTools', defaultTitle: 'Timers & utilities', category: 'utilities' }],
  },
]

function MenuLink({ tool, onNavigate }: { tool: Tool; onNavigate: () => void }) {
  return (
    <Link
      href={toolPath(tool.slug)}
      onClick={onNavigate}
      className="flex items-center gap-2.5 rounded-lg p-2 text-sm transition-colors hover:bg-accent min-h-[44px]"
    >
      <ToolIcon tool={tool} className="size-7 [&_svg]:size-4 shrink-0" />
      <span className="truncate">{tool.name}</span>
    </Link>
  )
}

export function DesktopNav() {
  const [openId, setOpenId] = useState<string | null>(null)
  const pathname = usePathname()
  const cleanPath = pathname?.replace(/\/$/, '') || '/'
  const isHome = cleanPath === '/'
  const { t } = useTranslation()
  const navRef = useRef<HTMLElement>(null)

  useEffect(() => setOpenId(null), [pathname])

  useEffect(() => {
    if (!openId) return
    const handlePointer = (event: PointerEvent) => {
      if (!navRef.current?.contains(event.target as Node)) setOpenId(null)
    }
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpenId(null)
    }
    document.addEventListener('pointerdown', handlePointer)
    document.addEventListener('keydown', handleKey)
    return () => {
      document.removeEventListener('pointerdown', handlePointer)
      document.removeEventListener('keydown', handleKey)
    }
  }, [openId])

  const close = () => setOpenId(null)

  return (
    <nav ref={navRef} aria-label="Main" className="relative hidden lg:block">
      <ul className="flex items-center gap-0.5 text-sm">
        {!isHome && (
          <li>
            <Link
              href="/"
              className="rounded-md px-3 py-2 text-foreground/80 transition-colors hover:bg-accent hover:text-foreground font-medium"
            >
              {t('whiteScreen', 'White Screen')}
            </Link>
          </li>
        )}

        {NAV_GROUPS.map((group) => {
          const isOpen = openId === group.id
          const label = t(group.translationKey, group.defaultLabel)
          const columns = group.sections.flatMap((section) => getToolsByCategory(section.category))
          return (
            <li key={group.id}>
              <button
                type="button"
                aria-expanded={isOpen}
                aria-controls={`menu-${group.id}`}
                onClick={() => setOpenId(isOpen ? null : group.id)}
                className={cn(
                  'inline-flex items-center gap-1 rounded-md px-3 py-2 text-foreground/80 transition-colors hover:bg-accent hover:text-foreground font-medium',
                  isOpen && 'bg-accent text-foreground font-semibold',
                )}
              >
                {label}
                <ChevronDown
                  className={cn('size-3.5 transition-transform', isOpen && 'rotate-180')}
                  aria-hidden="true"
                />
              </button>
              {isOpen && (
                <div
                  id={`menu-${group.id}`}
                  className={cn(
                    'absolute right-0 top-full z-50 mt-2 rounded-2xl border border-border bg-popover p-4 shadow-xl',
                    columns.length > 12 ? 'w-[46rem]' : 'w-[34rem]',
                  )}
                >
                  <div className="flex flex-col gap-4">
                    {group.sections.map((section) => (
                      <div key={section.category}>
                        <p className="mb-2 px-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                          {t(section.titleKey, section.defaultTitle)}
                        </p>
                        <ul
                          className={cn(
                            'grid gap-0.5',
                            columns.length > 12 ? 'grid-cols-3' : 'grid-cols-2',
                          )}
                        >
                          {getToolsByCategory(section.category).map((tool) => (
                            <li key={tool.slug}>
                              <MenuLink tool={tool} onNavigate={close} />
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </li>
          )
        })}

        <li>
          <Link
            href="/feedback"
            className={cn(
              'rounded-md px-3 py-2 text-foreground/80 transition-colors hover:bg-accent hover:text-foreground font-medium',
              pathname === '/feedback' && 'bg-accent text-foreground font-semibold',
            )}
          >
            {t('feedback', 'Feedback')}
          </Link>
        </li>
      </ul>
    </nav>
  )
}

export function MobileNav() {
  const [isOpen, setIsOpen] = useState(false)
  const [openGroup, setOpenGroup] = useState<string | null>(null)
  const pathname = usePathname()
  const cleanPath = pathname?.replace(/\/$/, '') || '/'
  const isHome = cleanPath === '/'
  const { t } = useTranslation()
  const menuRef = useRef<HTMLDivElement>(null)

  const close = () => {
    setIsOpen(false)
    setOpenGroup(null)
  }

  useEffect(() => {
    close()
  }, [pathname])

  useEffect(() => {
    if (!isOpen) return
    const handlePointer = (event: PointerEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) {
        close()
      }
    }
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        close()
      }
    }
    document.addEventListener('pointerdown', handlePointer)
    document.addEventListener('keydown', handleKey)
    return () => {
      document.removeEventListener('pointerdown', handlePointer)
      document.removeEventListener('keydown', handleKey)
    }
  }, [isOpen])

  const toggleGroup = (id: string) => {
    setOpenGroup((prev) => (prev === id ? null : id))
  }

  return (
    <div ref={menuRef} className="relative lg:hidden shrink-0">
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        aria-expanded={isOpen}
        aria-controls="mobile-dropdown-menu"
        className={cn(
          'inline-flex size-9 sm:size-10 items-center justify-center rounded-lg border border-border bg-background text-foreground transition-colors hover:bg-accent shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2',
          isOpen && 'border-primary/50 bg-accent text-foreground shadow-xs ring-1 ring-primary/20',
        )}
        aria-label={isOpen ? t('closeMenu', 'Close navigation menu') : t('menu', 'Open navigation menu')}
      >
        {isOpen ? (
          <X className="size-4 sm:size-5" aria-hidden="true" />
        ) : (
          <Menu className="size-4 sm:size-5" aria-hidden="true" />
        )}
      </button>

      {isOpen && (
        <div
          id="mobile-dropdown-menu"
          role="dialog"
          aria-modal="false"
          aria-label="Navigation menu"
          className="absolute right-0 top-full z-50 mt-2 w-[calc(100vw-1.25rem)] sm:w-96 max-w-sm rounded-2xl border border-border bg-popover p-3.5 sm:p-4 shadow-xl max-h-[calc(100vh-5rem)] overflow-y-auto animate-in fade-in-50 zoom-in-95"
        >
          {/* Dropdown Header */}
          <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-border/80">
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Navigation
            </span>
            <button
              type="button"
              onClick={close}
              className="inline-flex size-7 items-center justify-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
              aria-label={t('closeMenu', 'Close menu')}
            >
              <X className="size-4" aria-hidden="true" />
            </button>
          </div>

          {/* If on pillar page: White Screen navigation link */}
          {!isHome && (
            <div className="mb-2">
              <Link
                href="/"
                onClick={close}
                className="flex items-center justify-between rounded-xl border border-primary/30 bg-primary/5 px-3 py-2.5 text-sm font-semibold transition-colors hover:bg-primary/10 text-foreground"
              >
                <span className="flex items-center gap-2">
                  <Monitor className="size-4 text-primary" />
                  {t('whiteScreen', 'White Screen')}
                </span>
                <span className="text-xs text-primary font-medium">Home →</span>
              </Link>
            </div>
          )}

          {/* 5 Core Navigation Items */}
          <nav aria-label="Mobile Navigation Menu" className="flex flex-col gap-1.5">
            {NAV_GROUPS.map((group) => {
              const label = t(group.translationKey, group.defaultLabel)
              const isExpanded = openGroup === group.id
              const tools = group.sections.flatMap((section) => getToolsByCategory(section.category))

              return (
                <div key={group.id} className="rounded-xl border border-border bg-card overflow-hidden">
                  <div className="flex items-center justify-between p-0.5">
                    <Link
                      href={group.href}
                      onClick={close}
                      className="flex-1 px-3 py-2 text-sm font-semibold text-foreground hover:text-primary transition-colors text-left"
                    >
                      {label}
                    </Link>
                    <button
                      type="button"
                      onClick={() => toggleGroup(group.id)}
                      aria-expanded={isExpanded}
                      aria-label={`Toggle ${label} tools list`}
                      className="flex size-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground transition-colors mr-1"
                    >
                      <ChevronDown
                        className={cn('size-4 transition-transform duration-200', isExpanded && 'rotate-180')}
                        aria-hidden="true"
                      />
                    </button>
                  </div>

                  {isExpanded && (
                    <div className="border-t border-border/80 bg-muted/40 p-2 animate-in fade-in-50 duration-150">
                      <ul className="flex flex-col gap-0.5">
                        {tools.map((tool) => (
                          <li key={tool.slug}>
                            <MenuLink tool={tool} onNavigate={close} />
                          </li>
                        ))}
                      </ul>
                      <div className="pt-2 px-1 text-center border-t border-border/50 mt-1">
                        <Link
                          href={group.href}
                          onClick={close}
                          className="text-xs font-semibold text-primary hover:underline"
                        >
                          Browse all {label} →
                        </Link>
                      </div>
                    </div>
                  )}
                </div>
              )
            })}

            {/* 5: Feedback */}
            <Link
              href="/feedback"
              onClick={close}
              className={cn(
                'flex items-center justify-between rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm font-semibold text-foreground hover:bg-accent transition-colors',
                pathname === '/feedback' && 'border-primary/50 bg-primary/5 text-primary',
              )}
            >
              <span>{t('feedback', 'Feedback')}</span>
              <span className="text-xs text-muted-foreground">Suggestions →</span>
            </Link>
          </nav>

          {/* Secondary Footer Links inside Dropdown */}
          <div className="mt-3 flex items-center justify-between border-t border-border/80 pt-2.5 text-xs font-medium text-muted-foreground">
            <Link
              href="/tools"
              onClick={close}
              className="rounded-md px-2 py-1 hover:bg-accent hover:text-foreground transition-colors"
            >
              {t('allTools', 'All Tools')}
            </Link>
            <Link
              href="/about"
              onClick={close}
              className="rounded-md px-2 py-1 hover:bg-accent hover:text-foreground transition-colors"
            >
              {t('about', 'About Us')}
            </Link>
          </div>
        </div>
      )}
    </div>
  )
}

export function HeaderSearchLink() {
  return (
    <Link
      href="/tools"
      className="inline-flex size-9 sm:size-10 items-center justify-center rounded-lg border border-border bg-background text-foreground transition-colors hover:bg-accent lg:hidden shrink-0"
      aria-label="Search all tools"
    >
      <Search className="size-4" aria-hidden="true" />
    </Link>
  )
}
