import { ScreenTool } from '@/components/screen-tool/screen-tool'
import { useTranslation } from '@/lib/i18n'

type HeroProps = {
  colorId?: string
  title?: string
  intro?: string
}

export function Hero({
  colorId = 'white',
  title,
  intro,
}: HeroProps) {
  const { t } = useTranslation()

  const defaultTitle = colorId === 'white' ? t('heroTitle', 'White Screen') : `${t(colorId, colorId.charAt(0).toUpperCase() + colorId.slice(1))} Screen`
  const defaultIntro = colorId === 'white' ? t('heroIntro', 'Turn your display into a clean, bright white screen in one click. Use it as a light source, to test for dead pixels, or to clean your monitor — or switch to any other color.') : intro

  return (
    <section id="tool" aria-labelledby="hero-heading" className="scroll-mt-20 pb-8 pt-6 sm:pt-12">
      <div className="mx-auto max-w-6xl px-3 sm:px-6">
        <div className="mx-auto mb-6 sm:mb-8 max-w-2xl text-center">
          <h1
            id="hero-heading"
            className="text-balance text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tight"
          >
            {title ?? defaultTitle}
          </h1>
          <p className="mt-3 sm:mt-4 text-pretty text-sm sm:text-base md:text-lg leading-relaxed text-muted-foreground">
            {intro ?? defaultIntro}
          </p>
        </div>
        <ScreenTool key={colorId} initialColorId={colorId} />
      </div>
    </section>
  )
}
