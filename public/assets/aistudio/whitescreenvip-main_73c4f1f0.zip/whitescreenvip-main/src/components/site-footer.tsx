import Link from 'next/link'
import { Logo } from './logo'
import { footerNav } from '@/lib/site'
import { TOOL_CATEGORIES } from '@/lib/tool-categories'
import { getToolsByCategory, toolPath } from '@/lib/tools'
import { useTranslation } from '@/lib/i18n'

export function SiteFooter() {
  const { t } = useTranslation()

  const getFooterLabel = (label: string) => {
    if (label === 'About') return t('about', 'About')
    if (label === 'Contact') return t('contact', 'Contact')
    if (label === 'Feedback') return t('feedback', 'Feedback')
    if (label === 'Privacy Policy') return t('privacyPolicy', 'Privacy Policy')
    if (label === 'Terms of Use') return t('terms', 'Terms of Use')
    if (label === 'Disclaimer') return t('disclaimer', 'Disclaimer')
    return label
  }

  return (
    <footer className="border-t bg-muted/40">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1.2fr_3fr]">
        <div className="flex flex-col gap-3">
          <Logo />
          <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
            {t('footerDesc', 'Free screen tests, effects, screensavers and utilities that run entirely in your browser.')}
          </p>
          <nav aria-label="Site" className="mt-2">
            <ul className="flex flex-col gap-2 text-sm">
              {footerNav.map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="text-muted-foreground transition-colors hover:text-foreground">
                    {getFooterLabel(item.label)}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>
        <nav aria-label="Tools" className="grid gap-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
          {TOOL_CATEGORIES.map((category) => (
            <div key={category.id}>
              <h2 className="mb-3 text-sm font-semibold">{t(category.id, category.name)}</h2>
              <ul className="flex flex-col gap-2 text-sm">
                {getToolsByCategory(category.id).map((tool) => (
                  <li key={tool.slug}>
                    <Link
                      href={toolPath(tool.slug)}
                      className="text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {tool.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>
      </div>
      <div className="border-t">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-5 text-xs text-muted-foreground sm:flex-row sm:justify-between sm:px-6">
          <p>© {new Date().getFullYear()} {t('copyright', 'WhiteScreen.vip. All rights reserved.')}</p>
          <p>Simulations are for entertainment only and are not affiliated with any brand shown.</p>
        </div>
      </div>
    </footer>
  )
}
