import { Logo } from './logo'
import { DesktopNav, HeaderSearchLink, MobileNav } from './main-nav'
import { ToolSearch } from './tool-search'
import { LanguageSelector } from './language-selector'

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/80 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/85">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-1.5 sm:gap-4 px-2.5 sm:px-6">
        <Logo />
        <div className="flex flex-1 items-center justify-end gap-1.5 sm:gap-2 min-w-0">
          <DesktopNav />
          <ToolSearch
            placeholder="Search tools"
            className="hidden max-w-48 xl:max-w-56 lg:block"
          />
          <HeaderSearchLink />
          <LanguageSelector />
          <MobileNav />
        </div>
      </div>
    </header>
  )
}
