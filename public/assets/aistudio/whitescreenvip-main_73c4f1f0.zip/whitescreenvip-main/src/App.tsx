import { useEffect, lazy, Suspense } from 'react'
import { RouterProvider, usePathname } from '@/lib/next-shim'
import { I18nProvider, useTranslation } from '@/lib/i18n'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { HomePage } from '@/pages/HomePage'
import { ColorPage } from '@/pages/ColorPage'
import { getColorBySlug } from '@/lib/screen-colors'
import { TOOLS } from '@/lib/tools'
import { siteConfig } from '@/lib/site'

// Code-split secondary pages for optimal mobile performance
const ToolsPage = lazy(() => import('@/pages/ToolsPage').then(m => ({ default: m.ToolsPage })))
const ToolDetailPage = lazy(() => import('@/pages/ToolDetailPage').then(m => ({ default: m.ToolDetailPage })))
const AboutPage = lazy(() => import('@/pages/AboutPage').then(m => ({ default: m.AboutPage })))
const ContactPage = lazy(() => import('@/pages/ContactPage').then(m => ({ default: m.ContactPage })))
const FeedbackPage = lazy(() => import('@/pages/FeedbackPage').then(m => ({ default: m.FeedbackPage })))
const PrivacyPolicyPage = lazy(() => import('@/pages/PrivacyPolicyPage').then(m => ({ default: m.PrivacyPolicyPage })))
const TermsPage = lazy(() => import('@/pages/TermsPage').then(m => ({ default: m.TermsPage })))
const DisclaimerPage = lazy(() => import('@/pages/DisclaimerPage').then(m => ({ default: m.DisclaimerPage })))
const NotFoundPage = lazy(() => import('@/pages/NotFoundPage').then(m => ({ default: m.NotFoundPage })))

function PageLoading() {
  return (
    <div
      role="status"
      aria-label="Loading page"
      className="mx-auto flex max-w-4xl min-h-[50vh] items-center justify-center py-16 text-xs text-muted-foreground font-mono animate-pulse"
    >
      Loading content...
    </div>
  )
}

function AppContent() {
  const pathname = usePathname()
  const cleanPath = pathname.replace(/\/$/, '') || '/'
  const { t } = useTranslation()

  // Update document title dynamically
  useEffect(() => {
    if (cleanPath === '/') {
      document.title = siteConfig.title
    } else if (cleanPath === '/tools') {
      document.title = `${t('allTools', 'All Tools')} | WhiteScreen.vip`
    } else if (cleanPath === '/about') {
      document.title = `${t('about', 'About Us')} | WhiteScreen.vip`
    } else if (cleanPath === '/contact') {
      document.title = `${t('contact', 'Contact Us')} | WhiteScreen.vip`
    } else if (cleanPath === '/feedback') {
      document.title = `${t('feedback', 'Feedback & Suggestions')} | WhiteScreen.vip`
    } else if (cleanPath === '/privacy-policy') {
      document.title = `${t('privacyPolicy', 'Privacy Policy')} | WhiteScreen.vip`
    } else if (cleanPath === '/terms') {
      document.title = `${t('terms', 'Terms of Use')} | WhiteScreen.vip`
    } else if (cleanPath === '/disclaimer') {
      document.title = `${t('disclaimer', 'Disclaimer')} | WhiteScreen.vip`
    } else {
      const slug = cleanPath.slice(1)
      const color = getColorBySlug(slug)
      if (color) {
        document.title = `${color.name} Screen – Free Fullscreen ${color.name} Screen Tool`
      } else {
        const tool = TOOLS.find((t) => t.slug === slug)
        if (tool) {
          document.title = `${tool.name} – Free Online Screen Tool | WhiteScreen.vip`
        } else {
          document.title = 'Page Not Found | WhiteScreen.vip'
        }
      }
    }
  }, [cleanPath, t])

  let pageContent: React.ReactNode

  if (cleanPath === '/') {
    pageContent = <HomePage />
  } else if (cleanPath === '/tools') {
    pageContent = (
      <Suspense fallback={<PageLoading />}>
        <ToolsPage />
      </Suspense>
    )
  } else if (cleanPath === '/about') {
    pageContent = (
      <Suspense fallback={<PageLoading />}>
        <AboutPage />
      </Suspense>
    )
  } else if (cleanPath === '/contact') {
    pageContent = (
      <Suspense fallback={<PageLoading />}>
        <ContactPage />
      </Suspense>
    )
  } else if (cleanPath === '/feedback') {
    pageContent = (
      <Suspense fallback={<PageLoading />}>
        <FeedbackPage />
      </Suspense>
    )
  } else if (cleanPath === '/privacy-policy') {
    pageContent = (
      <Suspense fallback={<PageLoading />}>
        <PrivacyPolicyPage />
      </Suspense>
    )
  } else if (cleanPath === '/terms') {
    pageContent = (
      <Suspense fallback={<PageLoading />}>
        <TermsPage />
      </Suspense>
    )
  } else if (cleanPath === '/disclaimer') {
    pageContent = (
      <Suspense fallback={<PageLoading />}>
        <DisclaimerPage />
      </Suspense>
    )
  } else {
    const slug = cleanPath.slice(1)
    const color = getColorBySlug(slug)

    if (color) {
      pageContent = <ColorPage color={color} />
    } else {
      const tool = TOOLS.find((t) => t.slug === slug)
      if (tool) {
        pageContent = (
          <Suspense fallback={<PageLoading />}>
            <ToolDetailPage slug={slug} />
          </Suspense>
        )
      } else {
        pageContent = (
          <Suspense fallback={<PageLoading />}>
            <NotFoundPage />
          </Suspense>
        )
      }
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      <SiteHeader />
      <main id="main-content" className="flex-1">
        {pageContent}
      </main>
      <SiteFooter />
    </div>
  )
}

export default function App() {
  return (
    <I18nProvider>
      <RouterProvider>
        <AppContent />
      </RouterProvider>
    </I18nProvider>
  )
}
