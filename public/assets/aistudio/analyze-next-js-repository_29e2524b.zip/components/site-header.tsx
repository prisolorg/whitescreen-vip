import { Logo } from './logo'
import { DesktopNav, HeaderSearchLink, MobileNav } from './main-nav'
import { ToolSearch } from './tool-search'

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur supports-[backdrop-filter]:bg-background/70">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <Logo />
        <div className="flex flex-1 items-center justify-end gap-2">
          <DesktopNav />
          <ToolSearch
            placeholder="Search tools"
            className="hidden max-w-56 md:block"
          />
          <HeaderSearchLink />
          <MobileNav />
        </div>
      </div>
    </header>
  )
}
