'use client'

import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { ChevronDown, Menu, Search, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { getToolsByCategory, toolPath, type Tool } from '@/lib/tools'
import type { ToolCategoryId } from '@/lib/tool-categories'
import { ToolIcon } from './tool-card'
import { ToolSearch } from './tool-search'

type NavGroup = {
  id: string
  label: string
  href: string
  sections: { title: string; category: ToolCategoryId }[]
}

const NAV_GROUPS: NavGroup[] = [
  {
    id: 'screen-tests',
    label: 'Screen Tests',
    href: '/tools#screen-tests',
    sections: [{ title: 'Screen tests & colors', category: 'screen-tests' }],
  },
  {
    id: 'effects',
    label: 'Effects',
    href: '/tools#effects',
    sections: [
      { title: 'Visual effects', category: 'effects' },
      { title: 'Screensavers', category: 'screensavers' },
    ],
  },
  {
    id: 'fake-screens',
    label: 'Fake Screens',
    href: '/tools#fake-screens',
    sections: [{ title: 'Simulations', category: 'fake-screens' }],
  },
  {
    id: 'utilities',
    label: 'Other Tools',
    href: '/tools#utilities',
    sections: [{ title: 'Timers & utilities', category: 'utilities' }],
  },
]

function MenuLink({ tool, onNavigate }: { tool: Tool; onNavigate: () => void }) {
  return (
    <Link
      href={toolPath(tool.slug)}
      onClick={onNavigate}
      className="flex items-center gap-2.5 rounded-lg p-1.5 text-sm transition-colors hover:bg-accent"
    >
      <ToolIcon tool={tool} className="size-7 [&_svg]:size-4" />
      <span className="truncate">{tool.name}</span>
    </Link>
  )
}

export function DesktopNav() {
  const [openId, setOpenId] = useState<string | null>(null)
  const pathname = usePathname()
  const navRef = useRef<HTMLElement>(null)

  useEffect(() => setOpenId(null), [pathname])

  useEffect(() => {
    if (!openId) return
    const handlePointer = (event: PointerEvent) => {
      if (!navRef.current?.contains(event.target as Node)) setOpenId(null)
    }
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpenId(null)
    }
    document.addEventListener('pointerdown', handlePointer)
    document.addEventListener('keydown', handleKey)
    return () => {
      document.removeEventListener('pointerdown', handlePointer)
      document.removeEventListener('keydown', handleKey)
    }
  }, [openId])

  const close = () => setOpenId(null)

  return (
    <nav ref={navRef} aria-label="Main" className="relative hidden lg:block">
      <ul className="flex items-center gap-0.5 text-sm">
        {NAV_GROUPS.map((group) => {
          const isOpen = openId === group.id
          const columns = group.sections.flatMap((section) => getToolsByCategory(section.category))
          return (
            <li key={group.id}>
              <button
                type="button"
                aria-expanded={isOpen}
                aria-controls={`menu-${group.id}`}
                onClick={() => setOpenId(isOpen ? null : group.id)}
                className={cn(
                  'inline-flex items-center gap-1 rounded-md px-3 py-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground',
                  isOpen && 'bg-accent text-foreground',
                )}
              >
                {group.label}
                <ChevronDown
                  className={cn('size-3.5 transition-transform', isOpen && 'rotate-180')}
                  aria-hidden="true"
                />
              </button>
              {isOpen && (
                <div
                  id={`menu-${group.id}`}
                  className={cn(
                    'absolute right-0 top-full z-50 mt-2 rounded-2xl border bg-popover p-4 shadow-xl',
                    columns.length > 12 ? 'w-[46rem]' : 'w-[34rem]',
                  )}
                >
                  <div className="flex flex-col gap-4">
                    {group.sections.map((section) => (
                      <div key={section.category}>
                        <p className="mb-2 px-1.5 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                          {section.title}
                        </p>
                        <ul
                          className={cn(
                            'grid gap-0.5',
                            columns.length > 12 ? 'grid-cols-3' : 'grid-cols-2',
                          )}
                        >
                          {getToolsByCategory(section.category).map((tool) => (
                            <li key={tool.slug}>
                              <MenuLink tool={tool} onNavigate={close} />
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                    <Link
                      href={group.href}
                      onClick={close}
                      className="self-start rounded-md px-1.5 text-sm font-medium underline-offset-4 hover:underline"
                    >
                      {`View all ${group.label.toLowerCase()}`}
                    </Link>
                  </div>
                </div>
              )}
            </li>
          )
        })}
        <li>
          <Link
            href="/guides"
            className="rounded-md px-3 py-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            Guides
          </Link>
        </li>
      </ul>
    </nav>
  )
}

export function MobileNav() {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  useEffect(() => setIsOpen(false), [pathname])

  useEffect(() => {
    if (!isOpen) return
    const previous = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setIsOpen(false)
    }
    document.addEventListener('keydown', handleKey)
    return () => {
      document.body.style.overflow = previous
      document.removeEventListener('keydown', handleKey)
    }
  }, [isOpen])

  return (
    <div className="lg:hidden">
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        aria-expanded={isOpen}
        aria-controls="mobile-menu"
        className="inline-flex size-10 items-center justify-center rounded-lg border bg-background transition-colors hover:bg-accent"
        aria-label="Open menu"
      >
        <Menu className="size-5" aria-hidden="true" />
      </button>
      {isOpen && (
        <div
          id="mobile-menu"
          role="dialog"
          aria-modal="true"
          aria-label="Site menu"
          className="fixed inset-0 z-[60] flex flex-col bg-background"
        >
          <div className="flex h-16 shrink-0 items-center justify-between gap-3 border-b px-4">
            <span className="font-semibold">Menu</span>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="inline-flex size-10 items-center justify-center rounded-lg border hover:bg-accent"
              aria-label="Close menu"
            >
              <X className="size-5" aria-hidden="true" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto px-4 pb-10 pt-4">
            <ToolSearch onNavigate={() => setIsOpen(false)} />
            <div className="mt-6 flex flex-col gap-6">
              {NAV_GROUPS.flatMap((group) => group.sections).map((section) => (
                <section key={section.category} aria-label={section.title}>
                  <h2 className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    {section.title}
                  </h2>
                  <ul className="grid grid-cols-1 gap-0.5 sm:grid-cols-2">
                    {getToolsByCategory(section.category).map((tool) => (
                      <li key={tool.slug}>
                        <MenuLink tool={tool} onNavigate={() => setIsOpen(false)} />
                      </li>
                    ))}
                  </ul>
                </section>
              ))}
              <div className="flex flex-col gap-1 border-t pt-4 text-sm">
                <Link href="/tools" className="rounded-md p-1.5 font-medium hover:bg-accent">
                  All tools
                </Link>
                <Link href="/guides" className="rounded-md p-1.5 font-medium hover:bg-accent">
                  Guides
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export function HeaderSearchLink() {
  return (
    <Link
      href="/tools"
      className="inline-flex size-10 items-center justify-center rounded-lg border bg-background transition-colors hover:bg-accent md:hidden"
      aria-label="Search all tools"
    >
      <Search className="size-4" aria-hidden="true" />
    </Link>
  )
}
